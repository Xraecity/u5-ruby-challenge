class ProductsController < ApplicationController
  def index
  end
end
