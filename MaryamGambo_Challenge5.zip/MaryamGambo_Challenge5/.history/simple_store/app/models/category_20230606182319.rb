class Category < ApplicationRecord

end
