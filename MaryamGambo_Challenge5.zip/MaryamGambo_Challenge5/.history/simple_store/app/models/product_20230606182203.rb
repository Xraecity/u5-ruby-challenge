class Product < ApplicationRecord
  validates :title,:price,:stock_quantity,  presence: true
  belo
end
